<?php 
$is_deals = ($type == 'deals') ? true : false;
include NASA_CORE_PRODUCT_LAYOUTS . 'globals/row_layout.php';
